/** Automatically generated file. DO NOT MODIFY */
package com.example.z80v2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}