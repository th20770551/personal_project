package com.example.z80v2;





import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.content.Intent;


public class TextActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.textactivity);
		
		ActionBar actionBar = getActionBar();
		actionBar.hide();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	

	public void charCode(View view){//�����R�[�h�̕ϊ�
		EditText SENT = (EditText)this.findViewById(R.id.SENTENCE);//���͂̏\�i��
		String chars = SENT.getText().toString();
		//System.out.println(chars + "�Ɠ��͂��ꂽ");
		StringBuilder CodeResult = new StringBuilder();//�ϊ����ʂ��i�[
		
		for(int i = 0 ; i < chars.length() ; i++){
			
			switch(chars.charAt(i)){
			case ' ':
				CodeResult.append("10H ");
				break;
			case '!':
				CodeResult.append("21H ");
				break;
			case '"':
				CodeResult.append("22H ");
				break;
			case '#':
				CodeResult.append("23H ");
				break;
			case '$':
				CodeResult.append("24H ");
				break;
			case '%':
				CodeResult.append("25H ");
				break;
			case '&':
				CodeResult.append("26H ");
				break;
			case '\'':
				CodeResult.append("27H ");
				break;
			case '(':
				CodeResult.append("28H ");
				break;
			case ')':
				CodeResult.append("29H ");
				break;
			case '*':
				CodeResult.append("2AH ");
				break;
			case '+':
				CodeResult.append("2BH ");
				break;
			case ',':
				CodeResult.append("2CH ");
				break;
			case '-':
				CodeResult.append("2DH ");
				break;
			case '.':
				CodeResult.append("2EH ");
				break;
			case '/':
				CodeResult.append("2FH ");
				break;
			
			case '0':
				CodeResult.append("30H ");
				break;				
			case '1':
				CodeResult.append("31H ");
				break;					
			case '2':
				CodeResult.append("32H ");
				break;					
			case '3':
				CodeResult.append("33H ");
				break;	
			case '4':
				CodeResult.append("34H ");
				break;		
			case '5':
				CodeResult.append("35H ");
				break;	
			case '6':
				CodeResult.append("36H ");
				break;	
			case '7':
				CodeResult.append("37H ");
				break;	
			case '8':
				CodeResult.append("38H ");
				break;	
			case '9':
				CodeResult.append("39H ");
				break;	
			case ':':
				CodeResult.append("3AH ");
				break;	
			case ';':
				CodeResult.append("3BH ");
				break;	
			case '<':
				CodeResult.append("3CH ");
				break;	
			case '=':
				CodeResult.append("3DH ");
				break;	
			case '>':
				CodeResult.append("3EH ");
				break;	
			case '?':
				CodeResult.append("3FH ");
				break;	
				
				
			case '��':
				CodeResult.append("40H ");
				break;					
			case 'A':
				CodeResult.append("41H ");
				break;				
			case 'B':
				CodeResult.append("42H ");
				break;				
			case 'C':
				CodeResult.append("43H ");
				break;	
			case 'D':
				CodeResult.append("44H ");
				break;
			case 'E':
				CodeResult.append("45H ");
				break;	
			case 'F':
				CodeResult.append("46H ");
				break;
			case 'G':
				CodeResult.append("47H ");
				break;
			case 'H':
				CodeResult.append("48H ");
				break;
			case 'I':
				CodeResult.append("49H ");
				break;	
			case 'J':
				CodeResult.append("4AH ");
				break;	
			case 'K':
				CodeResult.append("4BH ");
				break;
			case 'L':
				CodeResult.append("4CH ");
				break;
			case 'M':
				CodeResult.append("4DH ");
				break;
			case 'N':
				CodeResult.append("4EH ");
				break;
			case 'O':
				CodeResult.append("4FH ");
				break;
			case 'P':
				CodeResult.append("50H ");
				break;				
			case 'Q':
				CodeResult.append("51H ");
				break;	
			case 'R':
				CodeResult.append("52H ");
				break;	
			case 'S':
				CodeResult.append("53H ");
				break;	
			case 'T':
				CodeResult.append("54H ");
				break;	
			case 'U':
				CodeResult.append("55H ");
				break;	
			case 'V':
				CodeResult.append("56H ");
				break;	
			case 'W':
				CodeResult.append("57H ");
				break;	
			case 'X':
				CodeResult.append("58H ");
				break;	
			case 'Y':
				CodeResult.append("59H ");
				break;	
			case 'Z':
				CodeResult.append("5AH ");
				break;	
			case '[':
				CodeResult.append("5BH ");
				break;	
			case '��':
				CodeResult.append("5CH ");
				break;	
			case ']':
				CodeResult.append("5DH ");
				break;	
			case '^':
				CodeResult.append("5EH ");
				break;	
			case '_':
				CodeResult.append("5FH ");
				break;	
				
			case '`':
				CodeResult.append("60H ");
				break;	
			case 'a':
				CodeResult.append("61H ");
				break;				
			case 'b':
				CodeResult.append("62H ");
				break;	
			case 'c':
				CodeResult.append("63H ");
				break;
			case 'd':
				CodeResult.append("64H ");
				break;
			case 'e':
				CodeResult.append("65H ");
				break;
			case 'f':
				CodeResult.append("66H ");
				break;
			case 'g':
				CodeResult.append("67H ");
				break;
			case 'h':
				CodeResult.append("68H ");
				break;
			case 'i':
				CodeResult.append("69H ");
				break;
			case 'j':
				CodeResult.append("6AH ");
				break;
			case 'k':
				CodeResult.append("6BH ");
				break;
			case 'l':
				CodeResult.append("6CH ");
				break;
			case 'm':
				CodeResult.append("6DH ");
				break;
			case 'n':
				CodeResult.append("6EH ");
				break;
			case 'o':
				CodeResult.append("6FH ");
				break;
			case 'p':
				CodeResult.append("70H ");
				break;	
			case 'q':
				CodeResult.append("71H ");
				break;					
			case 'r':
				CodeResult.append("72H ");
				break;	
			case 's':
				CodeResult.append("73H ");
				break;	
			case 't':
				CodeResult.append("74H ");
				break;	
			case 'u':
				CodeResult.append("75H ");
				break;	
			case 'v':
				CodeResult.append("76H ");
				break;	
			case 'w':
				CodeResult.append("77H ");
				break;	
			case 'x':
				CodeResult.append("78H ");
				break;	
			case 'y':
				CodeResult.append("79H ");
				break;	
			case 'z':
				CodeResult.append("7AH ");
				break;	
			case '{':
				CodeResult.append("7BH ");
				break;	
			case '|':
				CodeResult.append("7CH ");
				break;	
			case '}':
				CodeResult.append("7DH ");
				break;	
			case '��':
				CodeResult.append("7EH ");
				break;	
			case '��':
				CodeResult.append("7FH ");
				break;	
				
				
			case '�B':
				CodeResult.append("A1H ");
				break;		
			case '�u':
				CodeResult.append("A2H ");
				break;		
			case '�v':
				CodeResult.append("A3H ");
				break;	
			case '�A':
				CodeResult.append("A4H ");
				break;	
			case '�E':
				CodeResult.append("A5H ");
				break;	
				
				
	
				
			case '��':
			case '��':	
				CodeResult.append("A6H ");
				break;	
				
			case '��':
			case '�@':	
				CodeResult.append("A7H ");
				break;
				
			case '��':
			case '�B':	
				CodeResult.append("A8H ");
				break;	
				
			case '��':
			case '�D':	
				CodeResult.append("A9H ");
				break;
				
			case '��':
			case '�F':	
				CodeResult.append("AAH ");
				break;
				
			case '��':
			case '�H':	
				CodeResult.append("ABH ");
				break;
				
			case '��':
			case '��':	
				CodeResult.append("ACH ");
				break;
				
			case '��':
			case '��':	
				CodeResult.append("ADH ");
				break;
				
			case '��':
			case '��':	
				CodeResult.append("AEH ");
				break;
				
			case '��':
			case '�b':	
				CodeResult.append("AFH ");
				break;
				
			case '�[':
				CodeResult.append("B0H ");
				break;		
				
			case '��':
			case '�A':	
				CodeResult.append("B1H ");
				break;
				
			case '��':
			case '�C':	
				CodeResult.append("B2H ");
				break;
				
			case '��':
			case '�E':	
				CodeResult.append("B3H ");
				break;
				
			case '��':
			case '�G':	
				CodeResult.append("B4H ");
				break;
				
			case '��':
			case '�I':	
				CodeResult.append("B5H ");
				break;
				
			case '��':
			case '�J':	
				CodeResult.append("B6H ");
				break;
				
			case '��':
			case '�L':	
				CodeResult.append("B7H ");
				break;
				
			case '��':
			case '�N':	
				CodeResult.append("B8H ");
				break;
				
			case '��':
			case '�P':	
				CodeResult.append("B9H ");
				break;
				
			case '��':
			case '�R':	
				CodeResult.append("BAH ");
				break;
				
			case '��':
			case '�T':	
				CodeResult.append("BBH ");
				break;
				
			case '��':
			case '�V':	
				CodeResult.append("BCH ");
				break;	
				
			case '��':
			case '�X':	
				CodeResult.append("BDH ");
				break;
				
			case '��':
			case '�Z':	
				CodeResult.append("BEH ");
				break;
				
			case '��':
			case '�\':	
				CodeResult.append("BFH ");
				break;
				
			case '��':
			case '�^':	
				CodeResult.append("C0H ");
				break;			
				
			case '��':
			case '�`':	
				CodeResult.append("C1H ");
				break;			
				
			case '��':
			case '�c':	
				CodeResult.append("C2H ");
				break;		
				
			case '��':
			case '�e':	
				CodeResult.append("C3H ");
				break;	
				
			case '��':
			case '�g':	
				CodeResult.append("C4H ");
				break;	
				
			case '��':
			case '�i':	
				CodeResult.append("C5H ");
				break;	
				
			case '��':
			case '�j':	
				CodeResult.append("C6H ");
				break;	
				
			case '��':
			case '�k':	
				CodeResult.append("C7H ");
				break;	
				
			case '��':
			case '�l':	
				CodeResult.append("C8H ");
				break;	
				
			case '��':
			case '�m':	
				CodeResult.append("C9H ");
				break;	
				
			case '��':
			case '�n':	
				CodeResult.append("CAH ");
				break;		
				
			case '��':
			case '�q':	
				CodeResult.append("CBH ");
				break;	
				
			case '��':
			case '�t':	
				CodeResult.append("CCH ");
				break;	
				
			case '��':
			case '�w':	
				CodeResult.append("CDH ");
				break;	
				
			case '��':
			case '�z':	
				CodeResult.append("CEH ");
				break;	
				
			case '��':
			case '�}':	
				CodeResult.append("CFH ");
				break;	
				
			case '��':
			case '�~':	
				CodeResult.append("D0H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D1H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D2H ");
				break;				
				
			case '��':
			case '��':	
				CodeResult.append("D3H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D4H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D5H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D6H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D7H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D8H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("D9H ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("DAH ");
				break;		
				
			case '��':
			case '��':	
				CodeResult.append("DBH ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("DCH ");
				break;	
				
			case '��':
			case '��':	
				CodeResult.append("DDH ");
				break;	
				
			case '�J':	
				CodeResult.append("DEH ");
				break;	
				
			case '�K':	
				CodeResult.append("DFH ");
				break;					
				
				
				
				/*�ȉ��A�ǉ�����*/
				
			case '��':	
				CodeResult.append("E4H ");
				break;					
				
				
			case '��':	
				CodeResult.append("FDH ");
				break;					
				
				
				
			/* ���_�����̕ϊ��@*/	
			case '��':
			case '�K':	
				CodeResult.append("B6H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�M':	
				CodeResult.append("B7H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�O':	
				CodeResult.append("B8H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�Q':	
				CodeResult.append("B9H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�S':	
				CodeResult.append("BAH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�U':	
				CodeResult.append("BBH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�W':	
				CodeResult.append("BCH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�Y':	
				CodeResult.append("BDH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�[':	
				CodeResult.append("BEH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�]':	
				CodeResult.append("BFH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�_':	
				CodeResult.append("C0H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�a':	
				CodeResult.append("C1H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�d':	
				CodeResult.append("C2H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�f':	
				CodeResult.append("C3H ");
				CodeResult.append("DEH ");
				break;		
				
			case '��':
			case '�h':	
				CodeResult.append("C4H ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�o':	
				CodeResult.append("CAH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�r':	
				CodeResult.append("CBH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�u':	
				CodeResult.append("CCH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�x':	
				CodeResult.append("CDH ");
				CodeResult.append("DEH ");
				break;	
				
			case '��':
			case '�{':	
				CodeResult.append("CEH ");
				CodeResult.append("DEH ");
				break;	
				
			/* �����_�����̕ϊ��@*/	
				
			case '��':
			case '�p':	
				CodeResult.append("CAH ");
				CodeResult.append("DFH ");
				break;	
				
			case '��':
			case '�s':	
				CodeResult.append("CBH ");
				CodeResult.append("DFH ");
				break;					
				
			case '��':
			case '�v':	
				CodeResult.append("CCH ");
				CodeResult.append("DFH ");
				break;	
				
			case '��':
			case '�y':	
				CodeResult.append("CDH ");
				CodeResult.append("DFH ");
				break;	
				
			case '��':
			case '�|':	
				CodeResult.append("CEH ");
				CodeResult.append("DFH ");
				break;	
				

			default:
				CodeResult.append("10H ");
				
				
			}
		}
		SENT.setText(CodeResult.toString());
		
	}

	
	
	
	public void clearSENT(View view){
		EditText SENT = (EditText)this.findViewById(R.id.SENTENCE);
		SENT.getEditableText().clear();
	}

	
	
	
	public void BackToMain(View view){//������ʂ֖߂�
		finish();
	}

	
	
	
}
