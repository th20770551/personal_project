package com.example.z80v2;


import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.content.Intent;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void ChangeToTextMode(View view){//�e�L�X�g�ϊ����[�h�ւ̑J��
	      Intent intent=new Intent(this,TextActivity.class);
	      startActivityForResult(intent,0);
	}
	
	public void ChangeToVoltMode(View view){//�d���ϊ����[�h�ւ̑J��
	      Intent intent=new Intent(this,VoltActivity.class);
	      startActivityForResult(intent,0);
	}

	public void ChangeToOrderMode(View view){//���ߕ\�����[�h�ւ̑J��
	      Intent intent=new Intent(this,OrderActivity.class);
	      startActivityForResult(intent,0);
	}
	
	public void ChangeToIoMode(View view){//IO���[�h�ւ̑J��
	      Intent intent=new Intent(this,IoActivity.class);
	      startActivityForResult(intent,0);
	}
	
}
