package com.example.z80v2;





import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;


public class OrderActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ordersearchactivity);
		
		WebView  web = (WebView)findViewById(R.id.webView1);
		web.setWebViewClient(new WebViewClient());
		web.loadUrl("http://www.systemax.jp/doc/Z80_inst.html");
		
		ActionBar actionBar = getActionBar();
		actionBar.hide();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
	public void webReset(View view){
		WebView  web = (WebView)findViewById(R.id.webView1);
		web.setWebViewClient(new WebViewClient());
		web.loadUrl("http://www.systemax.jp/doc/Z80_inst.html");
	}
	
	public void BackToMain(View view){//������ʂ֖߂�
		finish();
	}

}
