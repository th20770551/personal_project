package com.example.z80v2;



import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


public class VoltActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.voltactivity);
		ActionBar actionBar = getActionBar();
		actionBar.hide();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
	
	public void DECtoBIN(View view){
		EditText DEC = (EditText)this.findViewById(R.id.DECtext);//���͂̏\�i��
		EditText BIN = (EditText)this.findViewById(R.id.BINtext);//�����o���Ώ�(2�i��)
		TextView HEX = (TextView)this.findViewById(R.id.HEX);//�����o���Ώ�(16�i��)
		
		
		String stemp = DEC.getText().toString();
		if(stemp.length() == 0){
			return;
		}
		
		double DECcounter = Double.parseDouble(stemp);
		
		//double DECcounter = Double.parseDouble(DEC.getText().toString());//�Ώۂ̐��l�̎��o��
		
		StringBuilder BINcounter = new StringBuilder();//�����߂��p(��i��)

		String HexCounter;// = "00";//16�i���̋L�^�p
		int hex1 = 0 , hex2 = 0;	//16�i�����ꂼ��̌��̐�
		String hex1c = "0", hex2c = "0";			//���A���ꂼ��̌��̐�
		
		
		//System.out.println("���l" + DECcounter + "�����͂��ꂽ");
		
		if(DECcounter > 5.0){//5.0V�ȏ�̓d���͏o�͂ł��Ȃ��̂Œe��
			Toast t1 = Toast.makeText(this,"5.0V�ȏ�̓d���͏o�͂ł��Ȃ�" , Toast.LENGTH_LONG);
			t1.show();
			return;
		}
		
		for(int i = 0 ; i < 8 ; i++){
			double temp = 2.5 * Math.pow(2, -1 * i);
			if(temp <= DECcounter){
				BINcounter.append('1');
				DECcounter -= temp;
			}else{
				BINcounter.append('0');
			}
		}
		BIN.setText(BINcounter.toString());
		
		for(int i = 0 ; i < 4 ; i++){
			if(BINcounter.toString().charAt(i) == '1'){
				hex1 += Math.pow(2 , 3 - i);
			}
			if(BINcounter.toString().charAt(i + 4) == '1'){
				hex2 += Math.pow(2, 3 - i);
			}
		}
		
		if(hex1 < 10){//10�ȉ��Ȃ�@�����̂܂ܐ�������
			hex1c = Integer.toString(hex1);
		}else{
			switch(hex1){
			case 10:
				hex1c = "A";
				break;
			case 11:
				hex1c = "B";
				break;
			case 12:
				hex1c = "C";
				break;
			case 13:
				hex1c = "D";
				break;
			case 14:
				hex1c = "E";
				break;
			case 15:
				hex1c = "F";
				break;
			default:	
			}
		}
		if(hex2 < 10){//10�ȉ��Ȃ�@�����̂܂ܐ�������
			hex2c = Integer.toString(hex2);
		}else{
			switch(hex2){
			case 10:
				hex2c = "A";
				break;
			case 11:
				hex2c = "B";
				break;
			case 12:
				hex2c = "C";
				break;
			case 13:
				hex2c = "D";
				break;
			case 14:
				hex2c = "E";
				break;
			case 15:
				hex2c = "F";
				break;
			default:
			}
		}		
		HexCounter = hex1c + hex2c + "H";
		//System.out.println("16�i����" + HexCounter);
		HEX.setText(HexCounter);
		
		
	}
	
	
	public void BINtoDEC(View view){
		//System.out.println("10�i���֕ϊ�");
		
		EditText DEC = (EditText)this.findViewById(R.id.DECtext);//�����o���Ώ�(10�i��)
		EditText BIN = (EditText)this.findViewById(R.id.BINtext);//���͌�
		TextView HEX = (TextView)this.findViewById(R.id.HEX);//�����o���Ώ�(16�i��)
		
		String HexCounter;// = "00";//16�i���̋L�^�p
		int hex1 = 0 , hex2 = 0;	//16�i�����ꂼ��̌��̐�
		String hex1c = "0", hex2c = "0";			//���A���ꂼ��̌��̐�
		
		
		String BINtemp = BIN.getText().toString();
		//System.out.println(BINtemp);
		
		if(BINtemp.length() != 8){
			//System.out.println("8bit�ł͂Ȃ�");
			Toast toast = Toast.makeText(this , "8bit�ł͂Ȃ�" , Toast.LENGTH_SHORT);
			toast.show();
			return;
		}
		
		for(int i = 0 ; i < 8 ; i++){
			if(  !( BINtemp.charAt(i) == '0'  || BINtemp.charAt(i) == '1'  ) ){
				Toast toast = Toast.makeText(this ,  "��i���ȊO���������Ă���", Toast.LENGTH_SHORT);
				toast.show();
				BIN.getEditableText().clear();//���͂������͊ԈႢ�Ȃ̂ŏ���
				return;
			}
		}
		
		DEC.getEditableText().clear();
		double DECcounter = 0.0;
		for(int i = 0 ; i < 8 ; i++){
			if(BINtemp.charAt(i) == '1'){
				DECcounter += Math.pow(2 , -1 * i);
			}
		}
		DECcounter *= 2.5;
		//System.out.println(DECcounter);
		DEC.setText(Double.toString(DECcounter));
		
		for(int i = 0 ; i < 4 ; i++){
			if(BINtemp.charAt(i) == '1'){
				hex1 += Math.pow(2 , 3 - i);
			}
			if(BINtemp.charAt(i + 4) == '1'){
				hex2 += Math.pow(2, 3 - i);
			}
		}
		
		if(hex1 < 10){//10�ȉ��Ȃ�@�����̂܂ܐ�������
			hex1c = Integer.toString(hex1);
		}else{
			switch(hex1){
			case 10:
				hex1c = "A";
				break;
			case 11:
				hex1c = "B";
				break;
			case 12:
				hex1c = "C";
				break;
			case 13:
				hex1c = "D";
				break;
			case 14:
				hex1c = "E";
				break;
			case 15:
				hex1c = "F";
				break;
			default:	
			}
		}
		if(hex2 < 10){//10�ȉ��Ȃ�@�����̂܂ܐ�������
			hex2c = Integer.toString(hex2);
		}else{
			switch(hex2){
			case 10:
				hex2c = "A";
				break;
			case 11:
				hex2c = "B";
				break;
			case 12:
				hex2c = "C";
				break;
			case 13:
				hex2c = "D";
				break;
			case 14:
				hex2c = "E";
				break;
			case 15:
				hex2c = "F";
				break;
			default:
			}
		}		
		HexCounter = hex1c + hex2c + "H";
		//System.out.println("16�i����" + HexCounter);
		HEX.setText(HexCounter);
		
	}
	
	
	public void clearBINandDEC(View view){
		EditText DEC = (EditText)this.findViewById(R.id.DECtext);
		EditText BIN = (EditText)this.findViewById(R.id.BINtext);
		TextView HEX = (TextView)this.findViewById(R.id.HEX);
		BIN.getEditableText().clear();
		DEC.getEditableText().clear();
		HEX.setText("00H");
		
	}
	
	
	
	
	public void BackToMain(View view){//������ʂ֖߂�
		finish();
	}

}
